# SQLIv

## Source

https://github.com/Hadesy2k/sqliv
 
## Usage:

```bash
cd sqliv/
docker build -t sqliv .
docker run -it sqliv:latest
```

## Help
```bash
docker run -it sqliv -d <SQLI DORK> -e <SEARCH ENGINE>
docker run -it sqliv -t <URL>    
```
