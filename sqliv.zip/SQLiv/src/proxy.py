import sys
import multiprocessing
import time
import psutil
import random

try:
    import urllib.request as urllib2
    from urllib.error import HTTPError, URLError
except ImportError:
    import urllib2
    from urllib2 import HTTPError, URLError

try:
    from urllib.parse import urlencode, quote_plus
except ImportError:
    from urllib import urlencode, quote_plus

import std
from web import web


def fetch_proxies_from_sources():
    """Fetch proxies from multiple online sources"""
    proxies = []
    sources = [
        "https://www.proxy-list.download/api/v1/get?type=http",
        "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&ssl=all&anonymity=all",
    ]
    
    for source in sources:
        try:
            std.stdout("fetching proxies from {}".format(source))
            request = urllib2.Request(source)
            reply = urllib2.urlopen(request, timeout=10)
            data = reply.read().decode('utf-8', errors='ignore')
            
            # Parse proxies from response (format: ip:port)
            lines = data.split('\n')
            for line in lines:
                line = line.strip()
                if line and ':' in line:
                    try:
                        ip, port = line.split(':')
                        port = int(port)
                        if 0 < port < 65536:
                            proxies.append("http://{}:{}".format(ip.strip(), port))
                    except:
                        pass
        except Exception as e:
            std.stderr("error fetching from {}: {}".format(source, e))
            continue
    
    return list(set(proxies))  # Remove duplicates


def validate_proxy(proxy):
    """Validate proxy by testing connection to Bing search"""
    try:
        proxy_handler = urllib2.ProxyHandler({'http': proxy, 'https': proxy})
        opener = urllib2.build_opener(proxy_handler)
        urllib2.install_opener(opener)
        
        # Test with a simple Bing search
        test_url = "http://www.bing.com/search?q=test"
        request = urllib2.Request(test_url)
        request.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0)')
        
        reply = urllib2.urlopen(request, timeout=5)
        if reply.getcode() == 200:
            return True
    except:
        pass
    
    return False


def validate_proxies(proxies):
    """Validate multiple proxies using multiprocessing"""
    if not proxies:
        return []
    
    std.stdout("validating {} proxies (this may take a while)".format(len(proxies)))
    valid_proxies = []
    
    pool = multiprocessing.Pool(processes=min(10, multiprocessing.cpu_count()))
    results = pool.map(validate_proxy, proxies)
    pool.close()
    pool.join()
    
    for proxy, is_valid in zip(proxies, results):
        if is_valid:
            valid_proxies.append(proxy)
            std.stdout("valid proxy: {}".format(proxy))
    
    if not valid_proxies:
        std.stderr("no valid proxies found")
        return []
    
    std.stdout("found {} valid proxies".format(len(valid_proxies)))
    return valid_proxies


def get_optimal_concurrent_tasks(num_proxies):
    """Calculate optimal number of concurrent tasks based on system resources"""
    try:
        cpu_count = psutil.cpu_count()
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
    except:
        cpu_count = multiprocessing.cpu_count()
        memory = None
        disk = None
    
    # Base calculation on CPU cores
    base_tasks = cpu_count * 2
    
    # Adjust based on memory
    if memory:
        # Estimate ~100MB per concurrent task
        memory_available_gb = memory.available / (1024 ** 3)
        memory_based_tasks = max(1, int(memory_available_gb / 0.1))
        base_tasks = min(base_tasks, memory_based_tasks)
    
    # Consider the number of proxies available
    if num_proxies > 0:
        base_tasks = min(base_tasks, num_proxies)
    
    # Hard limit to avoid resource exhaustion
    base_tasks = min(base_tasks, 50)
    
    return max(1, base_tasks)
