#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
#

"""
Author : Black Viking
Version: 0.0.1

https://gist.github.com/blackvkng/7487098fba261ac05f62c4676d33f350
"""

__name__    = 'python-bing'
__version__ = "0.0.1"

import re
import sys
import time
import gzip
import io

# Python 2/3 compatibility
try:
    # Python 3
    from urllib.parse import urlencode, quote_plus, urlparse, parse_qs
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from html import unescape
except Exception:
    # Python 2
    from urllib import urlencode, quote_plus
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urlparse import urlparse, parse_qs
    import StringIO as io
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

class Bing:
    def __init__(self):
        self.bingsearch = "http://www.bing.com/search?%s"

    def default_headers(self, name = __name__):
        '''
        :type name : str
        :param name: Name to add user-agent 

        :rtype: dict
        '''

        return {
            'Accept'         : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection'     : 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent'     : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0',
            'Referer'        : 'https://www.bing.com/'
            }

    def get_page(self, URL, timeout=15):
        '''
        :type URL : str
        :param URL: URL to get HTML source 
        :param timeout: timeout in seconds

        :rtpye: str
        '''
        
        try:
            request = Request(URL, headers=self.default_headers())
            resp = urlopen(request, timeout=timeout)
            html = resp.read()
            
            # Handle gzip compression if present
            if html[:2] == b'\x1f\x8b':  # gzip magic number
                try:
                    html = gzip.GzipFile(fileobj=io.BytesIO(html)).read()
                except:
                    pass
            
            # Debug: print size of response
            if html:
                size_kb = len(html) / 1024.0
                sys.stderr.write("[DEBUG] Received {} KB from {}\n".format(int(size_kb), URL))
            
            return html
        except HTTPError as e:
            sys.stderr.write("[DEBUG] HTTPError {}: {}\n".format(e.code, URL))
            raise
        except URLError as e:
            sys.stderr.write("[DEBUG] URLError: {} for {}\n".format(e.reason, URL))
            raise
        except Exception as e:
            sys.stderr.write("[DEBUG] Exception: {} for {}\n".format(e, URL))
            raise

    def parse_url_from_ck(self, ck_url):
        '''
        Extract actual URL from Bing /ck redirect link
        Bing uses: /ck/a?!&&url=<base64_encoded_url>
        We'll try to extract the url parameter
        '''
        try:
            # Try to parse the URL
            parsed = urlparse(ck_url)
            if 'url=' in parsed.query:
                params = parse_qs(parsed.query)
                if 'url' in params:
                    return params['url'][0]
            # If no url param, check if the entire query is a base64 encoded URL
            # For now, just return the ck URL as fallback
            return ck_url
        except:
            return ck_url

    def parse_links(self, html):
        '''
        :type html : str
        :param html: HTML source to find links

        :rtype: list
        '''

        if isinstance(html, bytes):
            try:
                html = html.decode('utf-8', errors='ignore')
            except:
                html = html.decode('latin-1', errors='ignore')

        # Decode HTML entities (&amp; -> &, etc.)
        html = unescape(html)

        if not BeautifulSoup:
            # Fallback to regex if BeautifulSoup not available
            # Look for /ck/ redirect links or direct URLs
            links = []
            
            # Find all /ck/ redirect links (including relative paths)
            ck_regex = re.compile(r'href=["\']?((?:https?://www\.bing\.com)?/ck/a\?[^"\'\s>]*)["\']?')
            for match in ck_regex.finditer(html):
                ck_link = match.group(1).strip()
                if ck_link.startswith('/'):
                    ck_link = 'http://www.bing.com' + ck_link
                extracted = self.parse_url_from_ck(ck_link)
                if extracted and 'bing' not in extracted.lower() and extracted.startswith('http'):
                    if extracted not in links:
                        links.append(extracted)
            
            sys.stderr.write("[DEBUG] Regex parse found {} links\n".format(len(links)))
            return links
        
        try:
            soup = BeautifulSoup(html, 'html.parser')
            links = []
            all_links = soup.find_all('a', href=True)
            
            sys.stderr.write("[DEBUG] Found {} total <a> tags\n".format(len(all_links)))
            
            # Find all result links - Bing uses various structures
            for link in all_links:
                href = link.get('href', '')
                
                # Skip Bing internal links
                if 'bing.com' in href.lower():
                    continue
                
                # Handle /ck/ redirect URLs
                if '/ck/' in href:
                    if href.startswith('/'):
                        href = 'http://www.bing.com' + href
                    extracted = self.parse_url_from_ck(href)
                    if extracted and 'bing' not in extracted.lower() and extracted.startswith('http'):
                        if extracted not in links:
                            links.append(extracted)
                # Handle direct URLs
                elif href.startswith('http://') or href.startswith('https://'):
                    if href not in links:
                        links.append(href)
            
            sys.stderr.write("[DEBUG] BeautifulSoup parse found {} valid links\n".format(len(links)))
            return links
        except Exception as e:
            sys.stderr.write("[DEBUG] Parse error: {}\n".format(e))
            return []

    def search(self, query, stop=100):
        '''
        :type query : str
        :param query: Query for search
        
        :type stop  : int
        :param stop : Last result to retrieve.

        :rtype: list
        '''
 
        links = []
        start = 1

        for page in range(int(round(int(stop), -1)) // 10):
            URL = (self.bingsearch % (urlencode({'q': query}))) + '&first=' + str(start)
            
            try:
                html   = self.get_page(URL)
                result = self.parse_links(html)

                [links.append(_) for _ in result if _ not in links]
            except Exception as e:
                sys.stderr.write("[DEBUG] Search error on page {}: {}\n".format(page, e))
                pass
            
            # Add delay to avoid rate limiting
            time.sleep(1)
            start = start + 10

        return links
