#!/usr/bin/env python
#-*- coding: utf-8 -*-
#
#

"""
Author : Black Viking
Version: 0.0.1

https://gist.github.com/blackvkng/7487098fba261ac05f62c4676d33f350
"""

__name__    = 'python-bing'
__version__ = "0.0.1"

import re
import sys

# Python 2/3 compatibility
try:
    # Python 3
    from urllib.parse import urlencode, quote_plus, urlparse, parse_qs
    from urllib.request import Request, urlopen
except Exception:
    # Python 2
    from urllib import urlencode, quote_plus
    from urllib2 import Request, urlopen
    from urlparse import urlparse, parse_qs

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

class Bing:
    def __init__(self):
        self.bingsearch = "http://www.bing.com/search?%s"

    def default_headers(self, name = __name__):
        '''
        :type name : str
        :param name: Name to add user-agent 

        :rtype: dict
        '''

        return {
            'Accept'         : 'text/html',
            'Connection'     : 'close',
            'User-Agent'     : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Encoding': 'identity'
            }

    def get_page(self, URL):
        '''
        :type URL : str
        :param URL: URL to get HTML source 

        :rtpye: str
        '''

        request = Request(URL, headers=self.default_headers())
        resp    = urlopen(request)

        return resp.read()

    def parse_url_from_ck(self, ck_url):
        '''
        Extract actual URL from Bing /ck redirect link
        Bing uses: /ck/a?!&&url=<base64_encoded_url>
        We'll try to extract the url parameter
        '''
        try:
            # Try to parse the URL
            parsed = urlparse(ck_url)
            if 'url=' in parsed.query:
                params = parse_qs(parsed.query)
                if 'url' in params:
                    return params['url'][0]
            # If no url param, check if the entire query is a base64 encoded URL
            # For now, just return the ck URL as fallback
            return ck_url
        except:
            return ck_url

    def parse_links(self, html):
        '''
        :type html : str
        :param html: HTML source to find links

        :rtype: list
        '''

        if not BeautifulSoup:
            # Fallback to regex if BeautifulSoup not available
            regex = re.compile(r'href="(/ck/a\?[^"]*)"')
            links = []
            for match in regex.finditer(html):
                ck_link = match.group(1)
                if ck_link.startswith('/'):
                    ck_link = 'http://www.bing.com' + ck_link
                extracted = self.parse_url_from_ck(ck_link)
                if extracted and 'bing' not in extracted.lower() and extracted.startswith('http'):
                    links.append(extracted)
            return links
        
        try:
            # Decode HTML if it's bytes
            if isinstance(html, bytes):
                try:
                    html = html.decode('utf-8', errors='ignore')
                except:
                    html = html.decode('latin-1', errors='ignore')
            
            soup = BeautifulSoup(html, 'html.parser')
            links = []
            
            # Find all result links - Bing uses various structures
            # Look for <a> tags with href containing /ck/ or starting with http
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                
                # Skip Bing internal links
                if 'bing.com' in href.lower():
                    continue
                
                # Handle /ck/ redirect URLs
                if '/ck/' in href:
                    if href.startswith('/'):
                        href = 'http://www.bing.com' + href
                    extracted = self.parse_url_from_ck(href)
                    if extracted and 'bing' not in extracted.lower() and extracted.startswith('http'):
                        if extracted not in links:
                            links.append(extracted)
                # Handle direct URLs
                elif href.startswith('http://') or href.startswith('https://'):
                    if href not in links:
                        links.append(href)
            
            return links
        except:
            # If BeautifulSoup parsing fails, return empty
            return []

    def search(self, query, stop=100):
        '''
        :type query : str
        :param query: Query for search
        
        :type stop  : int
        :param stop : Last result to retrieve.

        :rtype: list
        '''
 
        links = []
        start = 1

        for page in range(int(round(int(stop), -1)) // 10):
            URL = (self.bingsearch % (urlencode({'q': query}))) + '&first=' + str(start)

            html   = self.get_page(URL)
            result = self.parse_links(html)

            [links.append(_) for _ in result if _ not in links]

            start = start + 10

        return links
