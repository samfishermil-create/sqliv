import time
import signal
import multiprocessing
import base64
try:
    from urllib.parse import urlparse, unquote
except ImportError:
    from urlparse import urlparse
    from urllib import unquote

import std
import sqlerrors
from web import web
import common_domains


def init():
    signal.signal(signal.SIGINT, signal.SIG_IGN)

def _decode_bing_ck_url(url):
    """Decode Bing /ck/a redirect URL to actual destination"""
    try:
        if '/ck/a' not in url:
            return url
        
        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for param in parsed.query.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    params[key] = value
        
        if 'u' not in params:
            return url
        
        encoded_url = params['u']
        
        # Remove version/type prefix (typically first 2 characters like 'a1')
        if len(encoded_url) > 2:
            encoded_url = encoded_url[2:]
        elif len(encoded_url) > 1:
            encoded_url = encoded_url[1:]
        
        # Add padding if needed
        padding_needed = len(encoded_url) % 4
        if padding_needed:
            encoded_url += '=' * (4 - padding_needed)
        
        try:
            decoded = base64.b64decode(encoded_url).decode('utf-8', errors='ignore')
        except Exception:
            decoded = base64.urlsafe_b64decode(encoded_url).decode('utf-8', errors='ignore')
        
        final_url = unquote(decoded)
        
        if final_url and ('http' in final_url or '?' in final_url):
            std.stdout("[DEBUG] Decoded Bing /ck URL to: {}".format(final_url[:80]))
            return final_url
        
        return url
    except Exception as e:
        std.stderr("[DEBUG] Failed to decode Bing URL: {}".format(e))
        return url


def _is_valid_scan_url(url):
    """Check if URL should be scanned (not common domain, has domain, etc)"""
    try:
        # Skip if it's a common domain
        if common_domains.is_common_domain(url):
            std.stdout("[SKIP] Common domain: {}".format(url), end="")
            return False
        
        parsed = urlparse(url)
        
        # Skip if no domain
        if not parsed.netloc:
            std.stdout("[SKIP] No domain in URL: {}".format(url), end="")
            return False
        
        # Skip if it's just a directory path without a proper domain
        if parsed.netloc.startswith('/') or not ('.' in parsed.netloc or ':' in parsed.netloc):
            std.stdout("[SKIP] Invalid domain: {}".format(url), end="")
            return False
        
        return True
    except Exception:
        return False


def scan(urls, output_file=None):
    """scan multiple websites with multi processing"""

    vulnerables = []
    results = {}  # store scanned results

    childs = []  # store child processes
    max_processes = multiprocessing.cpu_count() * 2
    pool = multiprocessing.Pool(max_processes, init)

    for url in urls:
        # Decode if it's a Bing /ck redirect
        url = _decode_bing_ck_url(url)
        
        # Skip if not valid for scanning
        if not _is_valid_scan_url(url):
            continue
        
        def callback(result, url=url):
            results[url] = result
            if result[0] == True and output_file:
                std.append_dump(url, output_file)
        childs.append(pool.apply_async(__sqli, (url, ), callback=callback))

    try:
        while True:
            time.sleep(0.5)
            if all([child.ready() for child in childs]):
                break
    except KeyboardInterrupt:
        std.stderr("stopping sqli scanning process")
        pool.terminate()
        pool.join()
    else:
        pool.close()
        pool.join()

    for url, result in results.items():
        if result[0] == True:
            vulnerables.append((url, result[1]))

    return vulnerables


def __sqli(url):
    """check SQL injection vulnerability"""

    std.stdout("scanning {}".format(url), end="")

    domain = url.split("?")[0]  # domain with path without queries
    queries = urlparse(url).query.split("&")
    # no queries in url
    if not any(queries):
        print("") # move cursor to new line
        return False, None

    payloads = ("'", "')", "';", '"', '")', '";', '`', '`)', '`;', '\\', "%27", "%%2727", "%25%27", "%60", "%5C")
    for payload in payloads:
        website = domain + "?" + ("&".join([param + payload for param in queries]))
        source = web.gethtml(website)
        if source:
            vulnerable, db = sqlerrors.check(source)
            if vulnerable and db != None:
                std.showsign(" vulnerable")
                return True, db

    print("")  # move cursor to new line
    return False, None
