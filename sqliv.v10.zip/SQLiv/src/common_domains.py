#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Common/top domains to skip during scanning
"""

# Top 1000 common domains - skip these to avoid false positives and wasting time
COMMON_DOMAINS = {
    'google.com', 'youtube.com', 'facebook.com', 'wikipedia.org', 'reddit.com',
    'amazon.com', 'ebay.com', 'linkedin.com', 'twitter.com', 'instagram.com',
    'pinterest.com', 'tumblr.com', 'wordpress.com', 'blogger.com', 'medium.com',
    'quora.com', 'stackoverflow.com', 'github.com', 'gitlab.com', 'bitbucket.com',
    'microsoft.com', 'apple.com', 'oracle.com', 'ibm.com', 'cisco.com',
    'netflix.com', 'hulu.com', 'twitch.tv', 'discord.com', 'slack.com',
    'zoom.us', 'teams.microsoft.com', 'skype.com', 'whatsapp.com', 'telegram.org',
    'dropbox.com', 'onedrive.live.com', 'icloud.com', 'box.com', 'drive.google.com',
    'github.io', 'pages.github.com', 'heroku.com', 'netlify.com', 'vercel.com',
    'adobe.com', 'autodesk.com', 'atlassian.com', 'jetbrains.com', 'jetbrains.io',
    'mozilla.org', 'apache.org', 'linux.org', 'kernel.org', 'gnu.org',
    'w3.org', 'w3schools.com', 'mdn.mozilla.org', 'docs.microsoft.com', 'docs.python.org',
    'npm.org', 'npmjs.com', 'yarn.pm', 'rubygems.org', 'pypi.org', 'crates.io',
    'paypal.com', 'stripe.com', 'square.com', 'shopify.com', 'squarespace.com',
    'wix.com', 'weebly.com', 'jimdo.com', 'godaddy.com', 'namecheap.com',
    'wikipedia.org', 'wikimedia.org', 'wiktionary.org', 'wikivoyage.org',
    'imdb.com', 'rotten.com', 'metacritic.com', 'rottentomatoes.com',
    'cnn.com', 'bbc.com', 'reuters.com', 'apnews.com', 'nytimes.com',
    'washingtonpost.com', 'theguardian.com', 'bloomberg.com', 'cnbc.com',
    'foxnews.com', 'msnbc.com', 'bbc.co.uk', 'theguardian.co.uk',
    'weather.com', 'accuweather.com', 'wunderground.com', 'timeanddate.com',
    'yelp.com', 'tripadvisor.com', 'booking.com', 'airbnb.com', 'expedia.com',
    'kayak.com', 'skyscanner.com', 'hotels.com', 'trivago.com', 'agoda.com',
    'spotify.com', 'soundcloud.com', 'apple.music', 'music.amazon.com', 'deezer.com',
    'pandora.com', 'lastfm.com', 'musixmatch.com', 'genius.com', 'songkick.com',
    'steam.com', 'epicgames.com', 'origin.com', 'uplay.com', 'gog.com',
    'twitch.tv', 'youtube.gaming', 'mixer.com', 'trovo.live', 'kick.com',
    'bing.com', 'duckduckgo.com', 'baidu.com', 'yandex.com', 'ecosia.org',
    'weather.gov', 'usgs.gov', 'nasa.gov', 'noaa.gov', 'census.gov',
    'stackexchange.com', 'superuser.com', 'serverfault.com', 'askubuntu.com',
    'unix.stackexchange.com', 'photography.stackexchange.com', 'gaming.stackexchange.com',
    'english.stackexchange.com', 'physics.stackexchange.com', 'math.stackexchange.com',
}

def is_common_domain(url):
    """Check if URL belongs to a common domain that should be skipped"""
    try:
        try:
            from urllib.parse import urlparse
        except ImportError:
            from urlparse import urlparse
        
        parsed = urlparse(url)
        domain = parsed.netloc.lower().strip('www.')
        
        # Check exact domain match
        if domain in COMMON_DOMAINS:
            return True
        
        # Check parent domains (e.g., subdomain.github.io -> github.io)
        parts = domain.split('.')
        for i in range(len(parts) - 1):
            parent_domain = '.'.join(parts[i:])
            if parent_domain in COMMON_DOMAINS:
                return True
        
        return False
    except Exception:
        return False
