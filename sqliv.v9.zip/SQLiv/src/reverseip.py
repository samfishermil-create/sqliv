# Reverse Domain Lookup

from __future__ import print_function
import sys
import urllib
try:
    import urllib.request as urllib2
    from urllib.error import HTTPError, URLError
except ImportError:
    import urllib2
    from urllib2 import HTTPError, URLError

import json
try:
    from urllib.parse import urlparse, urlencode
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode

from web import useragents


def reverseip(url):
    """return domains from given the same server"""

    # get only domain name
    url = urlparse(url).netloc if urlparse(url).netloc != '' else urlparse(url).path.split("/")[0]

    source = "http://domains.yougetsignal.com/domains.php"
    useragent = useragents.get()
    contenttype = "application/x-www-form-urlencoded; charset=UTF-8"

    # POST method
    try:
        # Py3
        opener = urllib2.build_opener(
            urllib2.HTTPHandler(), urllib2.HTTPSHandler())
    except:
        # Py2
        opener = urllib2.build_opener(
            urllib2.HTTPHandler(), urllib2.HTTPSHandler())

    # data = urllib.urlencode([('remoteAddress', url), ('key', '')]) 
    # Use urlencode from correct module
    data = urlencode([('remoteAddress', url), ('key', '')]).encode('utf-8')

    request = urllib2.Request(source, data)
    request.add_header("Content-type", contenttype)
    request.add_header("User-Agent", useragent)

    try:
        result = urllib2.urlopen(request).read()

    except HTTPError as e:
        print("[{}] HTTP error".format(e.code), file=sys.stderr)

    except URLError as e:
        print("URL error, {}".format(e.reason), file=sys.stderr)

    except:
        print("HTTP exception", file=sys.stderr)

    else:
        try:
            obj = json.loads(result.decode('utf-8'))
        except:
             try:
                 obj = json.loads(result)
             except:
                 return []

        # if successful
        if obj.get("status") == 'Success':
            domains = []
            for domain in obj.get("domainArray", []):
                domains.append(domain[0])
            return domains

        print("[ERR] {}".format(obj.get("message", "")), file=sys.stderr)
        return []
    
    return []
